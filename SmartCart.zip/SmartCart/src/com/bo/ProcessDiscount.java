package com.bo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Categories;
import com.model.Category;
import com.model.Discounts;
import com.model.Item;
import com.model.Slab;

public class ProcessDiscount {
	double netTotal=0;
	double slabDiscount;
	StringBuilder finalInVoice=new StringBuilder();
	Map<String,Category> categoryMap=new HashMap<String,Category>();

	public void inItCategoryMap(Categories categories)
	{
		List<Category> cats=categories.getCategories();
		for(Category catObj:cats)
		{
			categoryMap.put(catObj.getId().toString(), catObj);	
		}
	}


	public String processBill(Categories categories,Discounts discounts,List<Item> itemsInCart)
	{
		inItCategoryMap(categories);
		double unitsCatTotalPrice;
		for(Item item:itemsInCart)
		{	
			String catId=item.getItemCategoryID();
			double totalForUnit=item.getQuantity()*item.getUnitPrice();
			int disCountForCategory=categoryMap.get(""+Integer.parseInt(catId)).getDiscPerc();		


			//one category item price after applying discount.
			unitsCatTotalPrice=calculateDiscounts(disCountForCategory,totalForUnit);
			finalInVoice.append("\nITEM NAME> "+item.getItemName()+"|ITEM QTY  "+item.getQuantity()+"|ITEM UNIT PRICE :"+item.getUnitPrice()+"|ITEM Dis For Cateogry:"+disCountForCategory+"|Total Price for the catefgory :"+unitsCatTotalPrice);
			netTotal=netTotal+unitsCatTotalPrice;


		}
		finalInVoice.append("\n"+"NET TOTAL"+netTotal);

		//slab wise apply discount to net total.
		finalInVoice.append("\n"+"GrAND TOTAL> "+calculateFinalGrandTotal(netTotal,discounts)+"\n|Applicable Slab DisCount Percentage >"+slabDiscount+"\n|Net Bill Amount(without slab) >"+netTotal);
		return generateInvoice(finalInVoice);
	}

	private String generateInvoice(StringBuilder finalInVoice) {
		return finalInVoice.toString();

	}

	private double calculateFinalGrandTotal(double netTotal,Discounts discounts) {
		List<Slab> slabs=discounts.getSlab();
		double grandTotal=0.0;
		for(Slab slab:slabs)
		{
			if(notZero(slab.getDiscPerc()))
			{
				if((notZero(slab.getRangeMax())))
				{
					if((netTotal<slab.getRangeMax()) &&(netTotal>slab.getRangeMin()))
					{
						grandTotal=calculateDiscounts(slab.getDiscPerc(),netTotal);
						slabDiscount=slab.getDiscPerc();
					}

				}
				else if((netTotal>slab.getRangeMin())&&(slab.getRangeMax()==0))
				{
					
					grandTotal=calculateDiscounts(slab.getDiscPerc(),netTotal);
					slabDiscount=slab.getDiscPerc();
				}
			}
			else
			{
				grandTotal=netTotal;
			}

		}
		return grandTotal;

	}

	public double calculateDiscounts(int disCountForCategory,double totalForUnit)
	{
		double discount=100-disCountForCategory;
		return discount*(totalForUnit/100);

	}
	private boolean notZero(double disCountPerc){
		boolean isZero=true;
		if(disCountPerc==0.0)
		{
			isZero=false;
		}
		else
		{
			isZero=true;
		}
		return isZero;
	}
}
