package com.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


//@XmlAccessorType (XmlAccessType.NONE)
@XmlRootElement(name="ShoppingCart")
public class Item {
	
	//@XmlElement(name="itemID")
	private String itemID;
	//@XmlElement(name="itemCategoryID")
	private String itemCategoryID;
	//@XmlElement(name="itemName")
	private String itemName;
	public String getItemID() {
		return itemID;
	}
	public void setItemID(String itemID) {
		this.itemID = itemID;
	}
	public String getItemCategoryID() {
		return itemCategoryID;
	}
	public void setItemCategoryID(String itemCategoryID) {
		this.itemCategoryID = itemCategoryID;
	}
	//@XmlElement(name="unitPrice")
	private double unitPrice;
	//@XmlElement(name="quantity")
	Integer quantity;
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}
