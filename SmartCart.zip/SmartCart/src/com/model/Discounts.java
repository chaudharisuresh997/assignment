package com.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FlatDiscountSlabs")
@XmlAccessorType (XmlAccessType.FIELD)
public class Discounts {

	@XmlElement(name = "Slab")
	public List<Slab> Slab=null;

	public List<Slab> getSlab() {
		return Slab;
	}

	public void setSlab(List<Slab> slab) {
		Slab = slab;
	}

}
